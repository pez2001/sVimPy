"""
 Fade
 
 This example shows how to fade an LED on pin 9
 using the analogWrite() function.
 
 This example code is in the public domain.
 
"""
import arduino

brightness = 0    # how bright the LED is
fadeAmount = 5    # how many points to fade the LED by

def setup():
	# declare pin 9 to be an output:
	pinMode(9, OUTPUT)


def loop():
	# set the brightness of pin 9:
	analogWrite(9, brightness)    

	# change the brightness for next time through the loop:
	brightness = brightness + fadeAmount

	# reverse the direction of the fading at the ends of the fade: 
	if (brightness == 0 or brightness == 255):
		fadeAmount = -fadeAmount 
     
	# wait for 30 milliseconds to see the dimming effect    
	delay(30)                            
