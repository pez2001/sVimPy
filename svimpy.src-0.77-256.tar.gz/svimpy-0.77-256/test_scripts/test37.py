def f(a,b): pass
a = {"a":1,"b":2}
f(**a)