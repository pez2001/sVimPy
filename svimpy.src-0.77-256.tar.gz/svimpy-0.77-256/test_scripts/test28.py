def f(i):
	if(i < 50):
		return(1)
	if(i > 50):
		return(0)
	if(i==50):
		return(-1)


print(f(0))
print(f(100))
print(f(50))
r = f(10)