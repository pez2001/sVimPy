a=1
b=20.2
c= a + b
print(c)