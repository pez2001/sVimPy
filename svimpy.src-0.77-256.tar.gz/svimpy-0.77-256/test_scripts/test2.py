x = 1
x = x + 1
print("x:",x)
