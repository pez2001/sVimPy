def f2():
	def f3():
		print("f3")
	f3()
f2()
