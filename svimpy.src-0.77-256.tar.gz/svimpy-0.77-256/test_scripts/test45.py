from test45_funcs import *
a=1
b=20.2
e= 0.0
f= 0.1
c= a + b
d = c + e + f
d = d *10.0
g = custom_code(d,c)
print(d)
print(g)