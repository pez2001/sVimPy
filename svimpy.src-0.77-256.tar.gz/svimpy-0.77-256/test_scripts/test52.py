a = [i*i for i in (1,2)]
print(a)