from testf import * 
print("compiled")
testf()
