def f():
	c = 1
	del c
f()
d = 1
del d

