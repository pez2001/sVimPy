for i in range(1,30):
	print(i)

