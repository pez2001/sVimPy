def f(a,b): pass
a = (1,2)
f(*a)