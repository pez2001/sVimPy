def main():
	x = True
	assert x == False,"error x not True"
main()
