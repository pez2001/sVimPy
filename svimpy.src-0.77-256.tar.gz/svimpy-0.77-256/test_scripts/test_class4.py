class test:
	def __init__(self, x):
		self.val = x
c = test("set")
d = test("new")
