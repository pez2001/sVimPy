a=1
b=20.2
e= 0.0
f= 0.1
c= a + b
d = c + e + f
print(d)