def testf():
	for x in range(1,3): 
		print(x,"Hallo")
	return
