def f7(a,b):
	print(a)
	print(b)

a = {"a":1,"b":2}
f7(**a)

