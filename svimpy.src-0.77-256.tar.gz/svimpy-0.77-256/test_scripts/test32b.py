def func(i):
	def sub_func(f):
		for b in range(0,f):
			print(a*b)
	a = 2
	sub_func(a)
func(2)

