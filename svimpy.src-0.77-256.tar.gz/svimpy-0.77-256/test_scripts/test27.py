def f():
	return 1

r = f()