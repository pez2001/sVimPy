class test:
	def __init__(self, x):
		print(x)
c = test("1")
