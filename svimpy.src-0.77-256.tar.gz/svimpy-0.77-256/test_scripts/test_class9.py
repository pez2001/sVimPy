class test:
	def init(self, x,y):
		self.val = x
		self.yval = y
		print(x,y)
c = test()
c.init("set","1")
d = test()
d.init("new","2")
