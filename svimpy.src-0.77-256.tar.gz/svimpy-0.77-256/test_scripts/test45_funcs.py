def custom_code(a,b):
	pass