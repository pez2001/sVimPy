a = 25
x = (1,2,a,5)
v = (1,4)
y = [1,"hi",3,99]
y[3]= v[1]
x = "hi"
print(x,"\n")
for a in range(1,4):
	print("a:",a)
print(x+"\n")
