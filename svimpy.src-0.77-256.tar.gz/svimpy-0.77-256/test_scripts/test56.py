def f(i):
	a = i
	return(a)
print(f(1))
