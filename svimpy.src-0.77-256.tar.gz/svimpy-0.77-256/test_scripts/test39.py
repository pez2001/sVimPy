def f(a,b,c): pass
f(1,2,3)