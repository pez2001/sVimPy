class test():
	def main(self):
		print("main")
t = test()
t.main()
t.main()
