x = "hi"
print(x,"\n")
for a in range(1,4):
	print("a:",a)
print(x+"\n")
