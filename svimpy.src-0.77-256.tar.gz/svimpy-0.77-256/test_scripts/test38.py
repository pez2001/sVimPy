def f(a,b,c): pass
a = {"b":1,"c":2}
b = (3,)
f(*b, **a)