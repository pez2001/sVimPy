def main():
	print("main")

if __name__ == "__main__":
	main()
