class test:
	def x(self, x):
		print(x)
c = test()
d = test()
