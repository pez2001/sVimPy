def imp_func():
	print("imp func")
print("root func")


