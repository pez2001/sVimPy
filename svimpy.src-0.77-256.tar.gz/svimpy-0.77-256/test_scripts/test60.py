a = (1,2,3)
for i in a:
	print(i)
for i in range(1):
	print(i)
for i in range(1,3):
	print(i)
for i in range(1,7,2):
	print(i)