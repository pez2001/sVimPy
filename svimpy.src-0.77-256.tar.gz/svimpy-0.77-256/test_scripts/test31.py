def f():
	a = {"a":1,"b":2}
	print(a["a"],"\n")
	a["a"] = 2
	print(a["a"],"\n")
f()