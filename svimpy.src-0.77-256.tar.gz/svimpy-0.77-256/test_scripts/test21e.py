def f():
	(ji,ki) = "hi"
	print("ji:",ji,"\n")
	print("ki:"+ki+"\n")
f()
