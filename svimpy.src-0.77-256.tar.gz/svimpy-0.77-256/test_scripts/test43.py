a=(0,1,2,3, ... ,65535)
for i in a:
	print(i)