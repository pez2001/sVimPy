def func():
	x = 11.1
	x = x + 11
	x = x * 3.3
	x = x - 21.5
	return x

o = func()
print ("func ret:",o,"\n")
o = o / 3.3
o = o + 20.5
o = o // 3.7
o = o // 2.1
for a in (1,2,3):
	print("a:",a,"\n")
print ("div:",o,"\n")
