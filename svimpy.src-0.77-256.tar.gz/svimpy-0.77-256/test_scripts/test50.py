def f7(a,b):
	print(a)
	print(b)

f7(b=2,a=1)
