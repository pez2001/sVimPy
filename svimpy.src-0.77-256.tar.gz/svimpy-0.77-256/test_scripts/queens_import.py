from queens import * 
#print("compiled")
main()
#testf()
