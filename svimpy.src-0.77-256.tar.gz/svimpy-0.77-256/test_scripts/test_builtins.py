#def f():
#	for i in (1,2,3):
#		yield i
#
#def f():
#	yield 1
#	yield 2
#	yield 3
#a = sum(1,2,3)
#print(a)
#g = f()
#b = sum(g)
#print(b)
#h = sum(g)
#print(h)
#i = f()
#j = sum(i)
#print(j)
#
#r = list(1,2,3)
#print(r)

for i in range(4):
	print(i)