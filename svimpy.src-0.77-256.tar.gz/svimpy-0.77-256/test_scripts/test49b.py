def f7(a,b):
	print(a)
	print(b)

a = {"b":2,"a":1}
f7(**a)
