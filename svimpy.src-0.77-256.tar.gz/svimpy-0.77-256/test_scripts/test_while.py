def func():
	i = 0
	while(i < 4):
		if(i == 1):
			i+=1
			continue
		if(i == 2):
			break
		i+=1
func()

