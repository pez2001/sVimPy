from test12 import * 

from test_import_func import imp_func

imp_func()
