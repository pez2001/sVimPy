from eratosthenes import * 
#print("compiled")
#testf()
