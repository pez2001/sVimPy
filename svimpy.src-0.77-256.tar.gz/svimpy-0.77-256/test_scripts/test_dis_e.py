import dis
import eratosthenes

dis.dis(eratosthenes)