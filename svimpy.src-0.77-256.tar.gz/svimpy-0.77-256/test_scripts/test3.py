x = 1
x = x + 1
x = x + x + 2
print("x:",x)
