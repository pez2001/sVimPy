def f():
	b = 0
	g = [0]
	g[b] += 1
f()

