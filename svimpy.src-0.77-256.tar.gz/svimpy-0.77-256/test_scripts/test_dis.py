import dis
import test_class

dis.dis(test_class)