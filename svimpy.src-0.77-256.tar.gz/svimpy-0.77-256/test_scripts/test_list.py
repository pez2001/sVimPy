r = list(1,2,3)
print(r)