/* 
 * sVimPy - small Virtual interpreting machine for Python
 */
