a = [1,2]
def f4(a,b):
	print(a)
	print(b)
f4(*a)
