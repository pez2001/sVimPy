def f():
	b = 0
	del b
f()

