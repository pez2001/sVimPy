for r in range(1,3):
	print(r)