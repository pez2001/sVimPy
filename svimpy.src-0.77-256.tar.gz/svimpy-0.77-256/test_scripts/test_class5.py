class test:
	def __init__(self, x,y):
		self.val = x
		self.yval = y
c = test("set","1")
d = test("new","2")
