def f():
	g = [0]
	g[0] += 1
f()

