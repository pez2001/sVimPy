def f6(a,b="Hi"):
	print(a)
	print(b)
f6("a","b")
f6("c")
