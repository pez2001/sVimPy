class test:
	def __init__(self, x):
		self.val = x
		print(self.val)
c = test("set")
