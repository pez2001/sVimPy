def fret():
	return(1)
r = fret()
print(r)