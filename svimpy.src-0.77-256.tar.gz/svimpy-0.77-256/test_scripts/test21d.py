def f():
	j = [1,2]
	del j[1]
f()

